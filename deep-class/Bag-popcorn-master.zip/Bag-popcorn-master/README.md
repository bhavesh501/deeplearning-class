When bag of words meets bags of popcorn
=======================================

I followed the official Kaggle tutorial of the competition https://www.kaggle.com/c/word2vec-nlp-tutorial. 

You can view the ipython notebook at
http://nbviewer.ipython.org/github/MatthieuBizien/Bag-popcorn/blob/master/Kaggle-Word2Vec.ipynb